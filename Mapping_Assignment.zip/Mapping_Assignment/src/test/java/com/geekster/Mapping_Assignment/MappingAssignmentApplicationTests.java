package com.geekster.Mapping_Assignment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MappingAssignmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
