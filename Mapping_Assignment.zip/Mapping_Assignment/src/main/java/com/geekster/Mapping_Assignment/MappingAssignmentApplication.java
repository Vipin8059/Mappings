package com.geekster.Mapping_Assignment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MappingAssignmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(MappingAssignmentApplication.class, args);
	}

}
